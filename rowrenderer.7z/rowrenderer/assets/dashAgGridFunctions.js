var dagfuncs = (window.dashAgGridFunctions = window.dashAgGridFunctions || {});

dagfuncs.customCellRendererSelector = (params) => {
    const numberDetails = {
        component: null,  // Render as plain text
    };

    const imageDetails = {
        component: dagcomponentfuncs.ImageRenderer,
    };

    // Check if the value looks like an image URL
    if (typeof params.value === 'string' && params.value.startsWith('http')) {
        return imageDetails;
    }
    return numberDetails;
};
