var dagcomponentfuncs = (window.dashAgGridComponentFunctions = window.dashAgGridComponentFunctions || {});

// Image Renderer
dagcomponentfuncs.ImageRenderer = params => {
    return React.createElement('img', {src: params.value, style: {width: '50px', height: '50px'}});
};
