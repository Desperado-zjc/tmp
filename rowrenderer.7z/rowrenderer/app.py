import dash_ag_grid as dag
from dash import Dash, html
import dash_bootstrap_components as dbc

# Initialize the Dash app
app = Dash(__name__, external_stylesheets=[dbc.icons.FONT_AWESOME])

# Update the row data with index names and remove the original columns from the displayed grid
rowData = [
    {'index': 'digits1', 'Column1': 12, 'Column2': 67, 'Column3': 89},
    {'index': 'digits2', 'Column1': 45, 'Column2': 23, 'Column3': 34},
    {'index': 'image', 'Column1': 'https://ts1.cn.mm.bing.net/th/id/R-C.b2deabf4f73362fdeded6ebb1759e6d5?rik=QTdjsA3RyD4v4g&riu=http%3a%2f%2fn.sinaimg.cn%2fsinacn20107%2f549%2fw600h749%2f20190427%2f07db-hvvuiyp2168388.jpg&ehk=ea6ytlOusTMhUxs4TgDNYQqymM8voeFn9db9ZiNcMOk%3d&risl=&pid=ImgRaw&r=0', 
     'Column2': 'https://ts1.cn.mm.bing.net/th/id/R-C.b2deabf4f73362fdeded6ebb1759e6d5?rik=QTdjsA3RyD4v4g&riu=http%3a%2f%2fn.sinaimg.cn%2fsinacn20107%2f549%2fw600h749%2f20190427%2f07db-hvvuiyp2168388.jpg&ehk=ea6ytlOusTMhUxs4TgDNYQqymM8voeFn9db9ZiNcMOk%3d&risl=&pid=ImgRaw&r=0', 
     'Column3': 'https://ts1.cn.mm.bing.net/th/id/R-C.b2deabf4f73362fdeded6ebb1759e6d5?rik=QTdjsA3RyD4v4g&riu=http%3a%2f%2fn.sinaimg.cn%2fsinacn20107%2f549%2fw600h749%2f20190427%2f07db-hvvuiyp2168388.jpg&ehk=ea6ytlOusTMhUxs4TgDNYQqymM8voeFn9db9ZiNcMOk%3d&risl=&pid=ImgRaw&r=0'},
]

# Update the column definitions to keep only the rendered columns
columnDefs = [
    {'headerName': 'Index', 'field': 'index'},  # Add index column
    {
        'headerName': 'Rendered Column1',
        'field': 'Column1',
        'cellRendererSelector': {"function": "customCellRendererSelector(params)"}
    },
    {
        'headerName': 'Rendered Column2',
        'field': 'Column2',
        'cellRendererSelector': {"function": "customCellRendererSelector(params)"}
    },
    {
        'headerName': 'Rendered Column3',
        'field': 'Column3',
        'cellRendererSelector': {"function": "customCellRendererSelector(params)"}
    },
]

# Dash layout with updated columns
app.layout = html.Div(
    [
        dag.AgGrid(
            id="image-rendering-grid",
            columnDefs=columnDefs,
            defaultColDef={'flex': 1, 'cellDataType': False},
            rowData=rowData,
        ),
    ],
)

if __name__ == "__main__":
    app.run(debug=True)
